<!DOCTYPE html>
<html> 
<head>
  <title>Inscription</title>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="profils.css">
  <style>
    body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-image: url("amo.jpg");
    background-repeat: no-repeat;
    background-size: cover;
}
    .text-container {
        background-color: #ffffff; /* Couleur de fond blanche pour le conteneur */
        padding: 20px;
        margin: 20px auto;
        max-width: 600px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    .error-message {
        color: red;
        font-weight: bold;
        margin-bottom: 10px;
    }
    .btn {
        display: inline-block;
        padding: 10px 20px;
        margin: 10px 5px;
        font-size: 16px;
        color: #ffffff;
        background-color: #007BFF;
        text-decoration: none;
        border-radius: 5px;
        transition: background-color 0.3s ease;
    }
    .btn:hover {
        background-color: #0056b3;
    }
    .submenu {
        list-style: none;
        padding: 0;
    }
    form fieldset {
        border: 1px solid #ddd;
        padding: 10px;
        margin-bottom: 20px;
    }
    form legend {
        padding: 0 10px;
        font-weight: bold;
    }
    form label {
        display: block;
        margin: 10px 0 5px;
    }
    form input, form select, form textarea {
        width: 100%;
        padding: 8px;
        box-sizing: border-box;
    }
    form input[type="radio"] {
        width: auto;
    }
    form input[type="submit"] {
        background-color: #007BFF;
        color: white;
        border: none;
        padding: 10px 15px;
        cursor: pointer;
        border-radius: 4px;
    }
    form input[type="submit"]:hover {
        background-color: #0056b3;
    }
  </style>
</head>
<body> 
    <div class="text-container">
        <a href="accueil.html" class="btn">Accueil</a>
        <a href="connexion.html" class="btn">Se connecter</a>
        <ul class="submenu">
            <!-- Additional submenu items can go here -->
        </ul>

        <h1>Veuillez vous inscrire</h1>

        <?php
        $sexe = $nom = $prenom = $pseudo = $date_naissance = $codepostal = $ville = $pays = $email = $pass = $bio = $profession = $statut_amoureux = $interets = $description_physique = '';
        $errors = [];

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $sexe = $_POST["sexe"];
            $nom = trim($_POST["nom"]);
            $prenom = trim($_POST["prenom"]);
            $pseudo = $_POST["pseudo"];
            $date_naissance = $_POST["date_naissance"];
            $codepostal = trim($_POST["codepostal"]);
            $ville = $_POST["ville"];
            $pays = $_POST["pays"];
            $email = trim($_POST["email"]);
            $pass = $_POST["pass"];
            $bio = $_POST["bio"];
            $profession = $_POST["profession"];
            $statut_amoureux = $_POST["statut_amoureux"];
            $interets = $_POST["interets"];
            $description_physique = $_POST["description_physique"];
            $avatar = "default.png"; // Valeur par défaut pour l'image

            // Validation du nom et du prénom
            if (empty($nom) || !preg_match("/^[a-zA-Z]+$/", $nom)) {
                $errors[] = "Le nom doit être renseigné et ne doit contenir que des lettres.";
            }

            if (empty($prenom) || !preg_match("/^[a-zA-Z]+$/", $prenom)) {
                $errors[] = "Le prénom doit être renseigné et ne doit contenir que des lettres.";
            }

            // Validation de l'email
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors[] = "L'adresse email n'est pas valide.";
            }

            // Validation de l'âge (au moins 18 ans)
            $current_date = new DateTime();
            $birth_date = new DateTime($date_naissance);
            $age = $current_date->diff($birth_date)->y;
            if ($age < 18) {
                $errors[] = "Vous devez avoir au moins 18 ans.";
            }

            // Validation du code postal (doit être un nombre)
            if (!preg_match("/^[0-9]{5}$/", $codepostal)) {
                $errors[] = "Le code postal doit contenir 5 chiffres.";
            }

            // Gestion simplifiée de l'upload de l'image
            if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] == 0) {
                $target_dir = "images/"; // Assurez-vous que ce répertoire existe
                if (!is_dir($target_dir)) {
                    mkdir($target_dir, 0777, true);
                }

                // Utiliser un nom unique pour le fichier d'image
                $target_file = $target_dir . uniqid() . '_' . basename($_FILES["avatar"]["name"]);
                
                // Déplacement du fichier uploadé vers le répertoire cible
                if (move_uploaded_file($_FILES["avatar"]["tmp_name"], $target_file)) {
                    $avatar = basename($target_file); // Nom du fichier uploadé
                }
            }

            if (empty($errors)) {
                $filename = 'utilisateurs.txt';

                // Ajout de "utilisateur", "a" et "2002-02-02" aux colonnes spécifiques
                $data = "$sexe,$nom,$prenom,$pseudo,$date_naissance,$codepostal,$ville,$pays,$email,utilisateur,$pass,a,2002-02-02,unb,$avatar,$bio,$profession,$statut_amoureux,$interets,$description_physique\n";

                file_put_contents($filename, $data, FILE_APPEND | LOCK_EX);
                echo '<p>Inscription réussie. <a href="connexion.html">Cliquez ici pour vous connecter</a>.</p>';
            } else {
                echo '<div class="error-message"><ul>';
                foreach ($errors as $error) {
                    echo "<li>$error</li>";
                }
                echo '</ul></div>';
            }
        }
        ?>

        <form method="POST" action="" enctype="multipart/form-data">
            <fieldset>
                <legend>Informations personnelles</legend>
                <label for="sexe">Sexe :</label><br>
                <input type="radio" id="sexe" name="sexe" value="homme" <?php if ($sexe == 'homme') echo 'checked'; ?> required>
                <label for="male">Homme</label><br>
                <input type="radio" id="sexe" name="sexe" value="femme" <?php if ($sexe == 'femme') echo 'checked'; ?> required>
                <label for="female">Femme</label><br>

                <br>
                <label for="nom">Votre Nom:</label>
                <input type="text" id="nom" name="nom" placeholder="Entrer votre nom..." value="<?php echo htmlspecialchars($nom); ?>" required>
                <br>
                <label for="prenom">Votre Prénom:</label>
                <input type="text" id="prenom" name="prenom" placeholder="Entrer votre prénom..." value="<?php echo htmlspecialchars($prenom); ?>" required>
                <br>
                <label for="pseudo">Votre Pseudo:</label>
                <input type="text" id="pseudo" name="pseudo" placeholder="Entrer votre pseudo..." value="<?php echo htmlspecialchars($pseudo); ?>" required>
                <br>
                <label for="date_naissance">Date de naissance:</label>
                <input type="date" id="date_naissance" name="date_naissance" max="2006-04" value="<?php echo htmlspecialchars($date_naissance); ?>" required>
                <br>
                <label for="codepostal">Code Postal:</label>
                <input type="text" id="codepostal" name="codepostal" placeholder="Entrer votre code postal..." value="<?php echo htmlspecialchars($codepostal); ?>" required>
                <br>
                <label for="ville">Ville:</label>
                <input type="text" id="ville" name="ville" placeholder="Entrer votre Ville..." value="<?php echo htmlspecialchars($ville); ?>" required>
                <br>
                <label for="pays">Pays:</label>
                <select id="pays" name="pays">
                    <option value="France" <?php if ($pays == 'France') echo 'selected'; ?>>France</option>
                    <!-- Autres options -->
                </select>
                <br>
                <label for="bio">Biographie:</label>
                <textarea id="bio" name="bio" placeholder="Écrire une courte biographie..." rows="4" cols="50"><?php echo htmlspecialchars($bio); ?></textarea>
                <br>
                <label for="interets">Centres d'intérêts:</label>
                <input type="text" id="interets" name="interets" placeholder="Entrer vos centres d'intérêts..." value="<?php echo htmlspecialchars($interets); ?>" required>
                <br>
                <label for="profession">Profession:</label>
                <input type="text" id="profession" name="profession" placeholder="Entrer votre profession..." value="<?php echo htmlspecialchars($profession); ?>" required>
                <br>
                <label for="statut_amoureux">Statut amoureux:</label>
                <select id="statut_amoureux" name="statut_amoureux" required>
                    <option value="celibataire" <?php if ($statut_amoureux == 'celibataire') echo 'selected'; ?>>Célibataire</option>
                    <option value="en_couple" <?php if ($statut_amoureux == 'en_couple') echo 'selected'; ?>>En couple</option>
                    <option value="marie" <?php if ($statut_amoureux == 'marie') echo 'selected'; ?>>Marié</option>
                    <option value="divorce" <?php if ($statut_amoureux == 'divorce') echo 'selected'; ?>>Divorcé</option>
                    <option value="veuf" <?php if ($statut_amoureux == 'veuf') echo 'selected'; ?>>Veuf</option>
                    <!-- Autres options -->
                </select>
                <br>
                <label for="description_physique">Description physique:</label>
                <textarea id="description_physique" name="description_physique" placeholder="Décrire votre apparence physique..." rows="4" cols="50" required><?php echo htmlspecialchars($description_physique); ?></textarea>
            </fieldset>
            <fieldset>
                <br>
                <legend>Informations de contact</legend>
                <label for="email">Votre E-mail:</label>
                <input type="email" id="email" name="email" placeholder="Entrer votre E-mail..." value="<?php echo htmlspecialchars($email); ?>" required>
                <br>
                <label for="pass">Votre Mot de passe:</label>
                <input type="password" id="pass" name="pass" placeholder="Entrer votre Mot de passe..." required>
                <br>
                <label for="avatar">Téléversez votre photo de profil:</label>
                <input type="file" id="avatar" name="avatar" accept="images/*" required>
                <br>
                <input type="submit" value="S'inscrire !!">
            </fieldset>
        </form>
    </div>
</body> 
</html>

