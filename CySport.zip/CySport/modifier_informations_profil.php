<?php
session_start();

// Fonction pour valider et assainir les entrées
function validate_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if (isset($_SESSION['email'])) {
    $filename = 'utilisateurs.txt';
    if (file_exists($filename)) {
        $users = file($filename, FILE_IGNORE_NEW_LINES);
        $current_user_email = $_SESSION['email'];
        $is_admin = false;

        // Vérifier si l'utilisateur connecté est un administrateur
        foreach ($users as $user) {
            $user_data = explode(',', $user);
            if (isset($user_data[8]) && $user_data[8] == $current_user_email && $user_data[9] == 'admin') {
                $is_admin = true;
                break;
            }
        }

        if (!$is_admin) {
            echo "Accès refusé. Vous n'êtes pas administrateur.";
            exit();
        }

        $email_to_edit = $_GET['email'];
        $user_to_edit = null;

        // Trouver l'utilisateur à éditer
        foreach ($users as $user) {
            $user_data = explode(',', $user);
            if ($user_data[8] == $email_to_edit) {
                $user_to_edit = $user_data;
                break;
            }
        }

        if (!$user_to_edit) {
            echo "Utilisateur non trouvé.";
            exit();
        }

        // Mettre à jour les informations de l'utilisateur
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $sexe = validate_input($_POST['sexe']);
            $nom = validate_input($_POST['nom']);
            $prenom = validate_input($_POST['prenom']);
            $pseudo = validate_input($_POST['pseudo']);
            $date_naissance = validate_input($_POST['date_naissance']);
            $code_postal = validate_input($_POST['code_postal']);
            $ville = validate_input($_POST['ville']);
            $pays = validate_input($_POST['pays']);
            $email = validate_input($_POST['email']);
            $bio = validate_input($_POST['bio']);
            $profession = validate_input($_POST['profession']);
            $statut_amoureux = validate_input($_POST['statut_amoureux']);
            $interets = validate_input($_POST['interets']);
            $description_physique = validate_input($_POST['description_physique']);

            // Validation de l'upload de l'image
            $avatar = $user_to_edit[14];
            if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] == 0) {
                $target_dir = "images/";
                if (!is_dir($target_dir)) {
                    mkdir($target_dir, 0777, true);
                }

                $target_file = $target_dir . uniqid() . '_' . basename($_FILES["avatar"]["name"]);
                if (move_uploaded_file($_FILES["avatar"]["tmp_name"], $target_file)) {
                    $avatar = basename($target_file);
                }
            }

            foreach ($users as $key => $user) {
                $user_data = explode(',', $user);
                if ($user_data[8] == $email) {
                    $user_data[0] = $sexe;
                    $user_data[1] = $nom;
                    $user_data[2] = $prenom;
                    $user_data[3] = $pseudo;
                    $user_data[4] = $date_naissance;
                    $user_data[5] = $code_postal;
                    $user_data[6] = $ville;
                    $user_data[7] = $pays;
                    $user_data[14] = $avatar;
                    $user_data[15] = $bio;
                    $user_data[16] = $profession;
                    $user_data[17] = $statut_amoureux;
                    $user_data[18] = $interets;
                    $user_data[19] = $description_physique;

                    $users[$key] = implode(',', $user_data);
                    file_put_contents($filename, implode("\n", $users));
                    header("Location: page_profil.php?status=success");
                    exit();
                }
            }
        }
        ?>
        <!DOCTYPE html>
        <html lang="fr">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Modifier les informations du profil</title>
            <link rel="stylesheet" href="modifier_informations_profil.css">
        </head>
        <body>
            <!-- HEADER -->
            <header class="bhead">
                <div class="header-title">
                    <a href="javascript:history.back()">Retour</a>
                </div>
                <div class="header-buttons">
                    <form method="post" action="logout.php">
                        <button type="submit">Se déconnecter</button>
                    </form>
                </div>
            </header>

            <div style="text-align: center;">
                        <h1>Modifier les informations de ce profil - Cy-Sport</h1>
                    </div>
            <form action="modifier_informations_profil.php?email=<?php echo urlencode($email_to_edit); ?>" method="POST" enctype="multipart/form-data">
                <label for="sexe">Sexe :</label>
                <select name="sexe">
                    <option value="homme" <?php if ($user_to_edit[0] == 'homme') echo 'selected'; ?>>Homme</option>
                    <option value="femme" <?php if ($user_to_edit[0] == 'femme') echo 'selected'; ?>>Femme</option>
                </select><br>
                <label for="nom">Nom :</label>
                <input type="text" name="nom" value="<?php echo validate_input($user_to_edit[1]); ?>"><br>
                <label for="prenom">Prénom :</label>
                <input type="text" name="prenom" value="<?php echo validate_input($user_to_edit[2]); ?>"><br>
                <label for="pseudo">Pseudo :</label>
                <input type="text" name="pseudo" value="<?php echo validate_input($user_to_edit[3]); ?>"><br>
                <label for="date_naissance">Date de naissance :</label>
                <input type="date" name="date_naissance" value="<?php echo validate_input($user_to_edit[4]); ?>"><br>
                <label for="code_postal">Code postal :</label>
                <input type="text" name="code_postal" value="<?php echo validate_input($user_to_edit[5]); ?>"><br>
                <label for="ville">Ville :</label>
                <input type="text" name="ville" value="<?php echo validate_input($user_to_edit[6]); ?>"><br>
                <label for="pays">Pays :</label>
                <input type="text" name="pays" value="<?php echo validate_input($user_to_edit[7]); ?>"><br>
                <label for="bio">Biographie :</label>
                <textarea name="bio"><?php echo validate_input($user_to_edit[15]); ?></textarea><br>
                <label for="profession">Profession :</label>
                <input type="text" name="profession" value="<?php echo validate_input($user_to_edit[16]); ?>"><br>
                <label for="statut_amoureux">Statut amoureux :</label>
                <select name="statut_amoureux">
                    <option value="celibataire" <?php if ($user_to_edit[17] == 'celibataire') echo 'selected'; ?>>Célibataire</option>
                    <option value="en_couple" <?php if ($user_to_edit[17] == 'en_couple') echo 'selected'; ?>>En couple</option>
                    <option value="marie" <?php if ($user_to_edit[17] == 'marie') echo 'selected'; ?>>Marié</option>
                    <option value="divorce" <?php if ($user_to_edit[17] == 'divorce') echo 'selected'; ?>>Divorcé</option>
                    <option value="veuf" <?php if ($user_to_edit[17] == 'veuf') echo 'selected'; ?>>Veuf</option>
                </select><br>
                <label for="interets">Centres d'intérêt :</label>
                <input type="text" name="interets" value="<?php echo validate_input($user_to_edit[18]); ?>"><br>
                <label for="description_physique">Description physique :</label>
                <textarea name="description_physique"><?php echo validate_input($user_to_edit[19]); ?></textarea><br>
                <label for="email">Email :</label>
                <input type="email" name="email" value="<?php echo validate_input($user_to_edit[8]); ?>" readonly><br>
                <label for="avatar">Photo de profil :</label>
                <input type="file" name="avatar" accept="image/*"><br>
                <button type="submit">Enregistrer les modifications</button>
            </form>
        </body>
        </html>
        <?php
        exit();
    } else {
        echo "Erreur : Fichier utilisateur introuvable.";
    }
} else {
    header("Location: connexion.html");
    exit();
}
?>

