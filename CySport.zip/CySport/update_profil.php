<?php
session_start();

// Fonction pour valider et assainir les entrées
function validate_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Fonction pour calculer l'âge à partir de la date de naissance
function calculate_age($birthday) {
    $birthDate = DateTime::createFromFormat('Y-m-d', $birthday);
    if ($birthDate === false) {
        return false;
    }
    $today = new DateTime('today');
    $age = $birthDate->diff($today)->y;
    return $age;
}

if (isset($_SESSION['email'])) {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $csrf_token = $_POST['csrf_token'];
        if ($csrf_token !== $_SESSION['csrf_token']) {
            echo "Erreur : CSRF token invalide.";
            exit();
        }

        $filename = 'utilisateurs.txt';
        $users = file($filename, FILE_IGNORE_NEW_LINES);

        foreach ($users as &$user) {
            $user_data = explode(',', $user);
            if ($user_data[8] == $_SESSION['email']) {
                // Récupérer les nouvelles données
                $new_gender = validate_input($_POST['sexe']);
                $new_lastname = validate_input($_POST['nom']);
                $new_firstname = validate_input($_POST['prenom']);
                $new_pseudo = validate_input($_POST['pseudo']);
                $new_birthday = validate_input($_POST['date_naissance']);
                $new_postalcode = validate_input($_POST['code_postal']);
                $new_city = validate_input($_POST['ville']);
                $new_country = validate_input($_POST['pays']);
                $new_email = validate_input($_POST['email']);
                $new_bio = validate_input($_POST['bio']);
                $new_profession = validate_input($_POST['profession']);
                $new_relationship_status = validate_input($_POST['statut_amoureux']);
                $new_interests = validate_input($_POST['interets']);
                $new_physical_description = validate_input($_POST['description_physique']);

                // Vérifier si la date de naissance est valide
                if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $new_birthday)) {
                    echo "Erreur : Format de date invalide. Utilisez le format AAAA-MM-JJ.";
                    exit();
                }

                // Calculer l'âge
                $age = calculate_age($new_birthday);
                if ($age === false) {
                    echo "Erreur : Date de naissance invalide.";
                    exit();
                }
                if ($age < 18) {
                    echo "Erreur : L'âge requis est de 18 ans";
                    exit();
                }

                // Mettre à jour les données de l'utilisateur
                $user_data[0] = $new_gender;
                $user_data[1] = $new_lastname;
                $user_data[2] = $new_firstname;
                $user_data[3] = $new_pseudo;
                $user_data[4] = $new_birthday;
                $user_data[5] = $new_postalcode;
                $user_data[6] = $new_city;
                $user_data[7] = $new_country;
                $user_data[8] = $new_email;
                $user_data[15] = $new_bio;
                $user_data[16] = $new_profession;
                $user_data[17] = $new_relationship_status;
                $user_data[18] = $new_interests;
                $user_data[19] = $new_physical_description;

                // Gérer la photo de profil
                if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] === UPLOAD_ERR_OK) {
                    $fileTmpPath = $_FILES['profile_pic']['tmp_name'];
                    $fileName = $_FILES['profile_pic']['name'];
                    $fileNameCmps = explode(".", $fileName);
                    $fileExtension = strtolower(end($fileNameCmps));
                    $newFileName = $new_email . '.' . $fileExtension;
                    $uploadFileDir = 'images/';
                    $dest_path = $uploadFileDir . $newFileName;
                    if (move_uploaded_file($fileTmpPath, $dest_path)) {
                        $user_data[14] = $newFileName;
                    } else {
                        echo "Une erreur s'est produite lors du téléchargement de votre photo de profil.";
                        exit();
                    }
                }

                // Enregistrer les modifications
                $user = implode(',', $user_data);
                file_put_contents($filename, implode(PHP_EOL, $users));

                header("Location: page_profil.php?update=success");
                exit();
            }
        }
        echo "Erreur : Utilisateur non trouvé.";
    } else {
        header("Location: get_profiles.php");
        exit();
    }
} else {
    header("Location: page_connexion.html");
    exit();
}
?>

