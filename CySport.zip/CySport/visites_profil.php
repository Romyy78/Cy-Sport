<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: connexion.html");
    exit();
}

$current_user_email = $_SESSION['email'];

$filename = 'utilisateurs.txt';
$users = file($filename, FILE_IGNORE_NEW_LINES);

$visits_filename = 'visites.txt';
$visits = file($visits_filename, FILE_IGNORE_NEW_LINES);
$visitors = [];

foreach ($visits as $visit) {
    list($visited_email, $visitor_email, $visit_date) = explode(',', $visit);
    if ($visited_email == $current_user_email) {
        $visitors[] = ['email' => $visitor_email, 'date' => $visit_date];
    }
}

function getUserByEmail($email, $users) {
    foreach ($users as $user) {
        $user_data = explode(',', $user);
        if ($user_data[8] == $email) {
            return $user_data;
        }
    }
    return null;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style2.css">
    <title>Visites de profil - Cy-Sport</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }
        .header {
            background-color: black;
            padding: 10px 20px;
            text-align: center;
            position: relative;
        }
        .header h1 {
            color: white;
            margin: 0;
        }
        .content {
            padding: 20px;
        }
        .visit {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
        }
        .visit img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 10px;
        }
        .visit h2 {
            font-size: 18px;
            margin: 0;
            color: #333;
        }
        .visit p {
            color: #666;
            margin: 5px 0 0;
        }
        .visit .profile-button {
            background-color: green;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
            transition: background-color 0.3s;
            margin-left: auto;
        }
        .visit .profile-button:hover {
            background-color: darkgreen;
        }
        .back-button {
            background-color: blue;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            text-decoration: none;
            transition: background-color 0.3s;
            display: inline-block;
            margin-top: 20px;
            position: absolute;
            left: 20px;
            top: 60px;
        }
        .back-button:hover {
            background-color: darkblue;
        }
        .logout-button {
            background-color: red;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            text-decoration: none;
            transition: background-color 0.3s;
            position: absolute;
            top: 10px;
            right: 20px;
        }
        .logout-button:hover {
            background-color: darkred;
        }
    </style>
</head>
<body>
    <div class="header" >
        <h1>Cy-Sport</h1>
        <form method="post" action="logout.php" style="display: inline;">
            <button type="submit" class="logout-button">Se déconnecter</button>
        </form>
        <a href="page_profil.php" class="back-button">Retour</a>
    </div>
    <div class="content" style="text-align: center;">
        <h2>Personnes ayant visité votre profil</h2>
        <?php
        if (empty($visitors)) {
            echo "<p>Aucune visite pour le moment.</p>";
        } else {
            foreach ($visitors as $visitor) {
                $visitor_data = getUserByEmail($visitor['email'], $users);
                if ($visitor_data) {
                    $visitor_name = htmlspecialchars($visitor_data[1]) . ' ' . htmlspecialchars($visitor_data[2]);
                    $visitor_image = htmlspecialchars($visitor_data[14]);
                    $visitor_image_path = 'images/' . $visitor_image;
                    if (!file_exists($visitor_image_path) || empty($visitor_image)) {
                        $visitor_image_path = 'images/default.png';
                    }
                    echo "<div class='visit'>";
                    echo "<img src='" . $visitor_image_path . "' alt='Photo de profil'>";
                    echo "<div>";
                    echo "<h2>" . $visitor_name . "</h2>";
                    echo "<p>Date de visite: " . htmlspecialchars($visitor['date']) . "</p>";
                    echo "</div>";
                    echo "<a href='consulterprof.php?email=" . urlencode($visitor['email']) . "' class='profile-button'>Consulter le profil</a>";
                    echo "</div>";
                }
            }
        }
        ?>
    </div>
</body>
</html>

