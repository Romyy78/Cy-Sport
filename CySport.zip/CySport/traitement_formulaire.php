<?php
session_start();

if(!empty($_POST)) {
    extract($_POST);
    $valid = true;
    if(isset($_POST["action"])) {
        switch($_POST["action"]) {
            case "ajouter":
                echo "Action: Ajouter en ami";
                // Traiter l'ajout en ami ici
                break;
            case "supprimer":
                echo "Action: Supprimer";
                // Traiter la suppression ici
                break;
            case "bloquer":
                echo "Action: Bloquer";
                // Traiter le blocage ici
                break;
            default:
                echo "Action non reconnue";
        }
    }
}
?>

