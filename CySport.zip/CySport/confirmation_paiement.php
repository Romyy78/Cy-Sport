<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: connexion.html");
    exit();
}

$status = isset($_GET['status']) ? $_GET['status'] : '';
$email = $_SESSION['email'];
$filename = 'utilisateurs.txt';
$currentDate = date('d-m-Y');

if ($status == 'success') {
    // Mettre à jour la date dans le fichier utilisateurs.txt
    $users = file($filename, FILE_IGNORE_NEW_LINES);
    $found = false;

    foreach ($users as &$user) {
        $userData = explode(',', $user);
        if (trim($userData[8]) == $email) {
            $userData[12] = $currentDate; // Mettre à jour la date de début d'abonnement
            $user = implode(',', $userData);
            $found = true;
            break;
        }
    }

    if ($found) {
        file_put_contents($filename, implode(PHP_EOL, $users) . PHP_EOL);
    }

    $message = "Paiement accepté. Vous serez redirigé vers votre profil.";
    $redirect = "page_profil.php";
} else {
    $message = "Paiement refusé. Vous serez redirigé vers votre profil.";
    $redirect = "page_profil.php";
}

header("refresh:5;url=$redirect"); // Redirection après 5 secondes
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="confirmation_paiement.css">
    <title>Confirmation du Paiement - Cy-Sport</title>
</head>
<body>
    <div class="header">
        <h1>Confirmation du Paiement</h1>
    </div>

    <div class="content">
        <div class="confirmation-message">
            <h2><?php echo $message; ?></h2>
            <p>Redirection en cours...</p>
        </div>
    </div>
</body>
</html>

