<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: connexion.html");
    exit();
}

$visits_filename = 'visites.txt';
$visits = file($visits_filename, FILE_IGNORE_NEW_LINES);
$current_user_email = $_SESSION['email'];
$visitor_emails = [];

// Trouver les visiteurs pour l'utilisateur actuel
foreach ($visits as $visit) {
    list($profile_email, $visitor_email, $visit_date) = explode(',', $visit);
    if ($profile_email == $current_user_email) {
        $visitor_emails[$visitor_email] = $visit_date;
    }
}

// Charger les détails des utilisateurs
$filename = 'utilisateurs.txt';
$users = file($filename, FILE_IGNORE_NEW_LINES);
$user_details = [];

foreach ($users as $user) {
    $user_data = explode(',', $user);
    $email = $user_data[8];
    if (isset($visitor_emails[$email])) {
        $user_details[] = [
            'name' => $user_data[1] . ' ' . $user_data[2],
            'email' => $email,
            'visit_date' => $visitor_emails[$email]
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="visites.css">
    <title>Visites du profil - Cy-Sport</title>
    <style>
        /* Style précédent */
    </style>
</head>
<body>
    <div class="header">
        <h1>Cy-sport</h1>
        <form method="post" action="logout.php" style="display: inline;">
            <button type="submit" class="button logout-button">Se déconnecter</button>
        </form>
    </div>
    <div class="content">
        <h2>Utilisateurs ayant visité votre profil</h2>
        <ul>
            <?php
            foreach ($user_details as $detail) {
                echo "<li>" . htmlspecialchars($detail['name']) . " - Visité le : " . htmlspecialchars($detail['visit_date']) . "</li>";
            }
            ?>
        </ul>
    </div>
</body>
</html>

