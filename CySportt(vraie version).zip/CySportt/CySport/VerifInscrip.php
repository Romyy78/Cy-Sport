<?php
if (isset($_POST['ok'])) {
    // Nettoyage et validation des données
    $sexe = filter_input(INPUT_POST, 'sexe', FILTER_SANITIZE_STRING);
    $nom = trim(filter_input(INPUT_POST, 'nom', FILTER_SANITIZE_STRING));
    $prenom = trim(filter_input(INPUT_POST, 'prenom', FILTER_SANITIZE_STRING));
    $pseudo = trim(filter_input(INPUT_POST, 'pseudo', FILTER_SANITIZE_STRING));
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    $pass = filter_input(INPUT_POST, 'pass', FILTER_SANITIZE_STRING);
    $codepostal = trim(filter_input(INPUT_POST, 'codepostal', FILTER_SANITIZE_STRING));
    $ville = trim(filter_input(INPUT_POST, 'ville', FILTER_SANITIZE_STRING));
    $pays = filter_input(INPUT_POST, 'pays', FILTER_SANITIZE_STRING);
    $description = htmlspecialchars(filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING));
    $message = htmlspecialchars(filter_input(INPUT_POST, 'message', FILTER_SANITIZE_STRING));

    if (!$email) {
        // Redirection vers le formulaire avec un message d'erreur
        header('Location: inscription.html?error=email');
        exit;
    }

    // Hashage du mot de passe
    $passHash = password_hash($pass, PASSWORD_DEFAULT);

    // Création du fichier si non existant et écriture sécurisée dans le fichier
    $filename = 'profils.php';
    if (!file_exists($filename)) {
        file_put_contents($filename, "<?php\nexit();\n?>\n", FILE_APPEND | LOCK_EX);
    }
    $data = "$nom,$prenom,$pseudo,$email,$passHash,$sexe,$codepostal,$ville,$pays,$description,$message" . PHP_EOL;
    if (file_put_contents($filename, $data, FILE_APPEND | LOCK_EX) === false) {
        header('Location: inscription.html?error=write');
        exit;
    }

    // Redirection sécurisée vers la page de connexion
    header("Location: connexion.html");
    exit;
}
?>
