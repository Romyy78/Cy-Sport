<?php
session_start();
if (!isset($_SESSION['email']) || !isset($_SESSION['offre'])) {
    header("Location: connexion.html");
    exit();
}

function is_valid_card_number($number) {
    // Remove all non-digit characters
    $number = preg_replace('/\D/', '', $number);
    // Check if the length is exactly 16 digits and if all digits are between 1 and 9
    return strlen($number) == 16 && preg_match('/^[1-9]+$/', $number);
}

function is_valid_expiry_date($expiry) {
    if (preg_match('/^(0[1-9]|1[0-2])\/([0-9]{2})$/', $expiry, $matches)) {
        $month = $matches[1];
        $year = '20' . $matches[2];
        if ($year > date('Y') || ($year == date('Y') && $month >= date('m'))) {
            return true;
        }
    }
    return false;
}

function is_valid_cvv($cvv) {
    return preg_match('/^[0-9]{3,4}$/', $cvv);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $card_number = preg_replace('/\s+/', '', $_POST['card_number']);
    $expiry_date = $_POST['expiry_date'];
    $cvv = $_POST['cvv'];

    if (!empty($card_number) && !empty($expiry_date) && !empty($cvv)) {
        if (is_valid_card_number($card_number) && is_valid_expiry_date($expiry_date) && is_valid_cvv($cvv)) {
            // Simulate a successful payment process
            $payment_successful = true; // Set to false to simulate a payment failure

            if ($payment_successful) {
                // Mettre à jour l'offre dans le fichier utilisateurs.txt
                $filename = '../data/utilisateurs.txt';
                $users = file($filename, FILE_IGNORE_NEW_LINES);
                $found_user_key = null;

                foreach ($users as $key => $user) {
                    $user_data = explode(',', $user);
                    if ($user_data[8] == $_SESSION['email']) {
                        $found_user_key = $key;
                        break;
                    }
                }

                if ($found_user_key !== null) {
                    $user_data = explode(',', $users[$found_user_key]);
                    $user_data[11] = $_SESSION['offre']; // Supposons que le champ de l'offre se trouve à la 11ème position (index 10)
                    $users[$found_user_key] = implode(',', $user_data);
                    file_put_contents($filename, implode(PHP_EOL, $users));

                    unset($_SESSION['offre']); // Supprimer l'offre de la session après mise à jour

                    header("Location: confirmation_paiement.php?status=success");
                    exit();
                } else {
                    header("Location: confirmation_paiement.php?status=error");
                    exit();
                }
            } else {
                header("Location: confirmation_paiement.php?status=error");
                exit();
            }
        } else {
            $error_message = "Informations de carte de crédit invalides.";
        }
    } else {
        $error_message = "Veuillez remplir tous les champs de paiement.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="paiement.css">
    <title>Paiement - Cy-Sport</title>
</head>
<body>
    <div class="header">
        <h1>Paiement</h1>
    </div>

    <div class="content">
        <div class="payment-form">
            <h2>Informations de paiement</h2>
            <?php
            if (isset($error_message)) {
                echo "<p class='error'>$error_message</p>";
            }
            ?>
            <form action="paiement.php" method="post">
                <input type="text" name="card_number" placeholder="Numéro de carte (16 chiffres)" required pattern="[1-9]{16}" title="Veuillez entrer 16 chiffres entre 1 et 9 sans espaces.">
                <input type="text" name="expiry_date" placeholder="Date d'expiration (MM/AA)" required pattern="(0[1-9]|1[0-2])\/\d{2}" title="Veuillez entrer une date au format MM/AA.">
                <input type="text" name="cvv" placeholder="CVV (3 ou 4 chiffres)" required pattern="\d{3,4}" title="Veuillez entrer 3 ou 4 chiffres.">
                <button type="submit">Valider le paiement</button>
            </form>
        </div>
    </div>
</body>
</html>

