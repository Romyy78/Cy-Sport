<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: connexion.html");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message_index = $_POST['message_index'];
    $contact_email = $_POST['contact_email'];

    $messages = file('messages.txt', FILE_IGNORE_NEW_LINES);

    if (isset($messages[$message_index])) {
        unset($messages[$message_index]);
        file_put_contents('messages.txt', implode(PHP_EOL, $messages) . PHP_EOL);
    }

    header("Location: messagerie.php?contact=" . urlencode($contact_email));
    exit();
}
?>

