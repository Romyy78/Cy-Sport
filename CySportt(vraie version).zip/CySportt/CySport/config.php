<?php
define('USER_DATA_FILE', '/var/data/utilisateurs.txt');
define('BLOCKED_USERS_FILE', '/var/data/blocked_users.txt');
?>

