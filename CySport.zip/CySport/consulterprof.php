<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: connexion.html");
    exit();
}

if (!isset($_GET['email'])) {
    header("Location: page_profil.php");
    exit();
}

$filename = 'utilisateurs.txt';
$users = file($filename, FILE_IGNORE_NEW_LINES);
$profile_email = $_GET['email'];
$current_user_email = $_SESSION['email'];
$profile_data = null;
$current_user_offer = null;

foreach ($users as $user) {
    $user_data = explode(',', $user);
    if (isset($user_data[8]) && $user_data[8] == $profile_email) {
        $profile_data = $user_data;
    }
    if (isset($user_data[8]) && $user_data[8] == $current_user_email) {
        $current_user_offer = strtolower($user_data[11]);
    }
}

if (!$profile_data) {
    header("Location: page_profil.php");
    exit();
}

$visits_filename = 'visites.txt';
$visit_entry = $profile_email . ',' . $current_user_email . ',' . date("d-m-Y H:i:s") . "\n";
file_put_contents($visits_filename, $visit_entry, FILE_APPEND);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="consulterprof.css">
    <title>Profil de <?php echo htmlspecialchars($profile_data[1]); ?> - Cy-Sport</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url("amo.jpg");
            background-repeat: no-repeat;
            background-size: cover;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Cy-sport</h1>
        <form method="post" action="logout.php" style="display: inline;">
            <button type="submit" class="button logout-button">Se déconnecter</button>
        </form>
    </div>
    <div class="content">
        <div class="profile-container">
            <a href="javascript:history.back()" class="back-button">Retour</a>
            <div class="profile">
                <?php
                $avatar = isset($profile_data[14]) ? htmlspecialchars($profile_data[14]) : '';
                $avatar_path = 'images/' . $avatar;
                if (!file_exists($avatar_path) || empty($avatar)) {
                    $avatar_path = 'images/default.png';
                }
                ?>
                <img src='<?php echo $avatar_path; ?>' alt='Photo de profil'>
                <h2><?php echo htmlspecialchars($profile_data[1]) . " " . htmlspecialchars($profile_data[2]); ?></h2>
                <p><strong>Date de naissance :</strong> <?php echo isset($profile_data[4]) ? htmlspecialchars($profile_data[4]) : 'N/A'; ?></p>
                <p><strong>Sexe :</strong> <?php echo isset($profile_data[0]) ? htmlspecialchars($profile_data[0]) : 'N/A'; ?></p>
                <p><strong>Pseudo :</strong> <?php echo isset($profile_data[3]) ? htmlspecialchars($profile_data[3]) : 'N/A'; ?></p>
                <p><strong>Bio :</strong> <?php echo isset($profile_data[15]) ? htmlspecialchars($profile_data[15]) : 'N/A'; ?></p>
                <p><strong>Profession :</strong> <?php echo isset($profile_data[16]) ? htmlspecialchars($profile_data[16]) : 'N/A'; ?></p>
                <p><strong>Situation amoureuse :</strong> <?php echo isset($profile_data[17]) ? htmlspecialchars($profile_data[17]) : 'N/A'; ?></p>
                <p><strong>Intérêts :</strong> <?php echo isset($profile_data[18]) ? htmlspecialchars($profile_data[18]) : 'N/A'; ?></p>
                <p><strong>Description physique :</strong> <?php echo isset($profile_data[19]) ? htmlspecialchars($profile_data[19]) : 'N/A'; ?></p>
                <p><strong>Code postal :</strong> <?php echo isset($profile_data[6]) ? htmlspecialchars($profile_data[6]) : 'N/A'; ?></p>
                <p><strong>Ville :</strong> <?php echo isset($profile_data[5]) ? htmlspecialchars($profile_data[5]) : 'N/A'; ?></p>
                <a href='envoyer_message.php?email=<?php echo urlencode($profile_email); ?>' class='action-button'>Envoyer un message</a>
            </div>
        </div>
    </div>
</body>
</html>

