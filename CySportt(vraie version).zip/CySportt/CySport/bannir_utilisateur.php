<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: connexion.html");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['ban_email'])) {
    $ban_email = filter_var($_POST['ban_email'], FILTER_VALIDATE_EMAIL);
    if ($ban_email) {
        $filename = '../data/utilisateurs.txt'; 
        $users = file($filename, FILE_IGNORE_NEW_LINES);

        $user_found = false;
        $is_admin = false;

        foreach ($users as $user) {
            $user_data = explode(',', $user);
            if ($user_data[8] == $ban_email) {
                if ($user_data[9] == 'admin') {
                    $is_admin = true;
                    break;
                }
            }
        }

        if ($is_admin) {
            header("Location: page_profil.php?status=error&message=" . urlencode("Vous ne pouvez pas bannir un administrateur."));
            exit();
        }

        foreach ($users as &$user) {
            $user_data = explode(',', $user);
            if ($user_data[8] == $ban_email) {
                // Ajouter "ban" après le nom de l'offre
                if (count($user_data) > 12) {
                    $user_data[13] = 'ban';
                } else {
                    $user_data[] = 'ban';
                }
                $user = implode(',', $user_data);
                $user_found = true;
                break;
            }
        }

        if ($user_found) {
            file_put_contents($filename, implode("\n", $users) . "\n");
            header("Location: page_profil.php?status=success");
            exit();
        } else {
            header("Location: page_profil.php?status=error&message=Utilisateur non trouvé");
            exit();
        }
    } else {
        header("Location: page_profil.php?status=error&message=Email invalide");
        exit();
    }
} else {
    header("Location: page_profil.php");
    exit();
}
?>

