<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: connexion.html");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message_content = $_POST['message_content'];
    $reported_by = $_SESSION['email'];
    $reported_datetime = date('Y-m-d H:i:s');
    $message_author = $_POST['message_author'];  // Capture the author of the message from the form

    $report_entry = "Message: $message_content, Auteur: $message_author, Signalé par: $reported_by, Date du signalement: $reported_datetime\n";

    file_put_contents('signalementsmessages.txt', $report_entry, FILE_APPEND);

    header("Location: messagerie.php?contact=" . urlencode($_POST['contact_email']));
    exit();
}
?>

