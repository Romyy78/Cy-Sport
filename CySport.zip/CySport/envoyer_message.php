<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: connexion.html");
    exit();
}

$users = file('utilisateurs.txt', FILE_IGNORE_NEW_LINES);
$user_lookup = [];
foreach ($users as $user) {
    list($sexe, $prenom, $nom, $autre, $naissance, $ville, $code_postal, $image_profil, $email, $mot_de_passe, $offre) = explode(',', $user);
    $user_lookup[$email] = $prenom . ' ' . $nom;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $to_email = $_POST['to_email'];
    $message_content = $_POST['message'];
    $from_email = $_SESSION['email'];
    $datetime = date('Y-m-d H:i:s'); // Ajout de la date et l'heure actuelles

    $message = "From: $from_email, To: $to_email, Message: $message_content, Datetime: $datetime\n";
    file_put_contents('messages.txt', $message, FILE_APPEND);
    header("Location: messagerie.php?contact=" . urlencode($to_email));
    exit();
}

$selected_contact_email = isset($_GET['email']) ? $_GET['email'] : null;
$selected_contact_name = $selected_contact_email ? $user_lookup[$selected_contact_email] : null;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="envoyer_message.css">
    <title>Envoyer un message - Cy-Sport</title>
</head>
<body>
    <div class="header">
        <a href="messagerie.php" class="back-button">Retour</a>
        <h1>Envoyer un message</h1>
    </div>

    <div class="content">
        <div class="message-form-container">
            <h2>Envoyer un message à <?php echo htmlspecialchars($selected_contact_name); ?></h2>
            <form method="post">
                <div class="form-group">
                    <label for="to_name">À :</label>
                    <input type="text" id="to_name" name="to_name" value="<?php echo htmlspecialchars($selected_contact_name); ?>" readonly>
                </div>
                <div class="form-group" style="display:none;">
                    <label for="to_email">Email :</label>
                    <input type="hidden" id="to_email" name="to_email" value="<?php echo htmlspecialchars($selected_contact_email); ?>">
                </div>
                <div class="form-group">
                    <label for="message">Message :</label>
                    <textarea id="message" name="message" required></textarea>
                </div>
                <div class="form-group">
                    <button type="submit">Envoyer</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>

