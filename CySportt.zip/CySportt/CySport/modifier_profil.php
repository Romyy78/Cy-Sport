<?php
session_start();

// Fonction pour valider et assainir les entrées
function validate_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if (isset($_SESSION['email'])) {
    $filename = '../data/utilisateurs.txt';
    if (file_exists($filename)) {
        $users = file($filename, FILE_IGNORE_NEW_LINES);
        foreach ($users as $user) {
            $user_data = explode(',', $user);
            if (isset($user_data[8]) && $user_data[8] == $_SESSION['email']) {
                $found = true;

                // Générer un token CSRF
                $csrf_token = bin2hex(random_bytes(32));
                $_SESSION['csrf_token'] = $csrf_token;
                ?>
                <!DOCTYPE html>
                <html lang="fr">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>Modifier le profil - Cy-Sport</title>
                    <link rel="stylesheet" href="modifier_profil.css">
                </head>
                <body>
                    <!-- HEADER -->
                    <header class="bhead">
                        <div class="header-title">
                            <a href="page_profil.php">Retour</a>
                        </div>
                        <div class="header-buttons">
                            <form method="post" action="logout.php">
                                <button type="submit">Se déconnecter</button>
                            </form>
                        </div>
                    </header>
                    <div style="text-align: center;">
                        <h1>Modifier les informations de ce profil - Cy-Sport</h1>
                    </div>
                    <form action="update_profil.php" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                        <label for="sexe">Sexe :</label>
                        <select name="sexe">
                            <option value="homme" <?php if ($user_data[0] == 'homme') echo 'selected'; ?>>Homme</option>
                            <option value="femme" <?php if ($user_data[0] == 'femme') echo 'selected'; ?>>Femme</option>
                        </select><br>
                        <label for="nom">Nom :</label>
                        <input type="text" name="nom" value="<?php echo validate_input($user_data[1]); ?>"><br>
                        <label for="prenom">Prénom :</label>
                        <input type="text" name="prenom" value="<?php echo validate_input($user_data[2]); ?>"><br>
                        <label for="pseudo">Pseudo :</label>
                        <input type="text" name="pseudo" value="<?php echo validate_input($user_data[3]); ?>"><br>
                        <label for="date_naissance">Date de naissance :</label>
                        <input type="date" name="date_naissance" value="<?php echo validate_input($user_data[4]); ?>"><br>
                        <label for="code_postal">Code postal :</label>
                        <input type="text" name="code_postal" value="<?php echo validate_input($user_data[5]); ?>"><br>
                        <label for="ville">Ville :</label>
                        <input type="text" name="ville" value="<?php echo validate_input($user_data[6]); ?>"><br>
                        <label for="pays">Pays :</label>
                        <input type="text" name="pays" value="<?php echo validate_input($user_data[7]); ?>"><br>
                        <label for="bio">Biographie :</label>
                        <textarea name="bio"><?php echo validate_input($user_data[15]); ?></textarea><br>
                        <label for="profession">Profession :</label>
                        <input type="text" name="profession" value="<?php echo validate_input($user_data[16]); ?>"><br>
                        <label for="statut_amoureux">Statut amoureux :</label>
                        <select name="statut_amoureux">
                            <option value="celibataire" <?php if ($user_data[17] == 'celibataire') echo 'selected'; ?>>Célibataire</option>
                            <option value="en_couple" <?php if ($user_data[17] == 'en_couple') echo 'selected'; ?>>En couple</option>
                            <option value="marie" <?php if ($user_data[17] == 'marie') echo 'selected'; ?>>Marié</option>
                            <option value="divorce" <?php if ($user_data[17] == 'divorce') echo 'selected'; ?>>Divorcé</option>
                            <option value="veuf" <?php if ($user_data[17] == 'veuf') echo 'selected'; ?>>Veuf</option>
                        </select><br>
                        <label for="interets">Centres d'intérêt :</label>
                        <input type="text" name="interets" value="<?php echo validate_input($user_data[18]); ?>"><br>
                        <label for="description_physique">Description physique :</label>
                        <textarea name="description_physique"><?php echo validate_input($user_data[19]); ?></textarea><br>
                        <label for="email">Email :</label>
                        <input type="email" name="email" value="<?php echo validate_input($user_data[8]); ?>" readonly><br>
                        <label for="profile_pic">Photo de profil :</label>
                        <input type="file" name="profile_pic"><br>
                        <button type="submit">Enregistrer les modifications</button>
                    </form>
                </body>
                </html>
                <?php
                exit();
            }
        }
        if (!$found) {
            echo "Erreur : Utilisateur non trouvé.";
        }
    } else {
        echo "Erreur : Fichier utilisateur introuvable.";
    }
} else {
    header("Location: connexion.html");
    exit();
}
?>

