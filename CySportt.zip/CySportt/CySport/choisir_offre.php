<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: connexion.html");
    exit();
}

$email = $_SESSION['email'];
$offreEnCours = null;
$dateFinAbonnement = null;
$is_admin = false;

// Function to calculate the end date of subscription
function calculateEndDate($startDate, $plan) {
    $date = new DateTime($startDate);
    $plan = strtolower($plan); // Convertir le plan en minuscules
    switch ($plan) {
        case "basique":
            $date->modify('+1 month');
            break;
        case "premium":
            $date->modify('+3 months');
            break;
        case "black":
            $date->modify('+1 year');
            break;
        default:
            throw new Exception("Type d'abonnement inconnu : " . $plan);
    }
    return $date->format('d/m/Y');
}

// Read user data from the file
$file = fopen('../data/utilisateurs.txt', "r");
if ($file) {
    while (($line = fgets($file)) !== false) {
        $userData = explode(",", $line);
        if (trim($userData[8]) == $email) { // Vérifier si l'email correspond
            if (isset($userData[9]) && trim($userData[9]) == 'admin') {
                $is_admin = true;
            }
            if (isset($userData[11]) && isset($userData[12])) {
                $offreEnCours = trim($userData[11]);
                if (strtolower($offreEnCours) != 'a') {
                    $dateDebutAbonnement = trim($userData[12]);
                    try {
                        $dateFinAbonnement = calculateEndDate($dateDebutAbonnement, $offreEnCours);
                    } catch (Exception $e) {
                        echo "Erreur: " . $e->getMessage();
                        exit();
                    }
                }
            }
            break;
        }
    }
    fclose($file);
} else {
    echo "Erreur lors de l'ouverture du fichier utilisateurs.txt";
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="choisir_offre.css">
    <title>Choisir une offre d'abonnement - Cy-Sport</title>
</head>
<body>
    <div class="header">
        <a href="page_profil.php" class="back-button">Retour</a>
        <h1 style="text-align: center;">Choisir une offre d'abonnement</h1>
    </div>

    <div class="content-section">
        <?php if ($is_admin): ?>
            <div class="current-offer">
                <h2>Offre en cours</h2>
                <p>Vous êtes admin donc abonné à vie</p>
            </div>
        <?php else: ?>
            <?php if ($offreEnCours): ?>
                <div class="current-offer">
                    <h2>Offre en cours</h2>
                    <?php if (strtolower($offreEnCours) == 'a'): ?>
                        <p>Vous n'avez pas d'abonnement pour le moment.</p>
                    <?php else: ?>
                        <p><?php echo htmlspecialchars($offreEnCours); ?></p>
                        <p>Votre abonnement se termine le : <?php echo htmlspecialchars($dateFinAbonnement); ?></p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <div class="photos-section">
            <?php
            $offers = [
                "Basique" => ["Accès et messagerie illimitée", "8 euros par mois"],
                "Premium" => ["Accès et messagerie illimitée", "20 euros pour 3 mois"],
                "Black" => ["Accès et messagerie illimitée", "60 euros par an"]
            ];

            foreach ($offers as $offer => $details) {
                echo '<div class="offer">';
                echo '<h2>' . htmlspecialchars($offer) . '</h2>';
                echo '<p>' . htmlspecialchars($details[0]) . '</p>';
                echo '<p>' . htmlspecialchars($details[1]) . '</p>';
                echo '<form action="abonnement.php" method="post">';
                echo '<input type="hidden" name="offre" value="' . htmlspecialchars($offer) . '">';
                if ($is_admin) {
                    echo '<button type="submit" class="choose-button disabled" disabled>Choisir cette offre</button>';
                } elseif (strtolower($offer) === strtolower($offreEnCours)) {
                    echo '<button type="submit" class="choose-button disabled" disabled>Déjà sélectionnée</button>';
                } else {
                    echo '<button type="submit" class="choose-button">Choisir cette offre</button>';
                }
                echo '</form>';
                echo '</div>';
            }
            ?>
        </div>
    </div>
</body>
</html>

