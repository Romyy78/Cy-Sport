<?php
session_start();
if (!isset($_SESSION['email']) || !isset($_GET['email'])) {
    header("Location: connexion.html");
    exit();
}

$reported_email = $_GET['email'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $message = $_POST["message"];
    $filename = 'signalements.txt';
    $current_user_email = $_SESSION['email'];
    $data = "$current_user_email,$reported_email,$message\n";
    file_put_contents($filename, $data, FILE_APPEND | LOCK_EX);
    header("Location: page_profil.php?status=success&message=" . urlencode("Utilisateur signalé avec succès."));
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="signaler.css">
    <title>Signaler un utilisateur</title>
</head>
<body>
    <div class="container">
        <h2>Signaler un utilisateur</h2>
        <form method="post">
            <textarea name="message" placeholder="Expliquez la cause du signalement" required></textarea>
            <button type="submit">Envoyer le signalement</button>
        </form>
    </div>
</body>
</html>

