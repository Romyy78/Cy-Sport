<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: connexion.html");
    exit();
}

// Chemins relatifs vers les fichiers dans le dossier parent
$users_filename = '../data/utilisateurs.txt';
$messages_filename = '../data/messages.txt';
$blocked_filename = '../data/blocked_users.txt';

// Vérifiez que les fichiers existent avant de les lire
if (!file_exists($users_filename) || !file_exists($messages_filename) || !file_exists($blocked_filename)) {
    die('Un ou plusieurs fichiers de données sont introuvables.');
}

// Lire les utilisateurs
$users = file($users_filename, FILE_IGNORE_NEW_LINES);
$user_lookup = [];
$user_images = [];
foreach ($users as $user) {
    list($sexe, $prenom, $nom, $pseudo, $naissance, $ville, $code_postal, $pays, $email, $mot_de_passe, $role, $couleur_preferee, $date_expiration, $status, $image_profil) = explode(',', $user);
    $user_lookup[$email] = $prenom . ' ' . $nom;
    $user_images[$email] = $image_profil;
}

// Lire les messages
$messages = file($messages_filename, FILE_IGNORE_NEW_LINES);
$contact_messages = [];
foreach ($messages as $index => $message) {
    if (preg_match('/From: ([^,]+), To: ([^,]+), Message: (.+), Datetime: (.+)/', $message, $matches)) {
        $from_email = trim($matches[1]);
        $to_email = trim($matches[2]);
        $message_content = trim($matches[3]);
        $message_datetime = trim($matches[4]);

        if ($to_email == $_SESSION['email'] || $from_email == $_SESSION['email']) {
            $contact_email = ($to_email == $_SESSION['email']) ? $from_email : $to_email;
            $contact_name = $user_lookup[$contact_email];
            if (!isset($contact_messages[$contact_email])) {
                $contact_messages[$contact_email] = [
                    'name' => $contact_name,
                    'messages' => []
                ];
            }
            $contact_messages[$contact_email]['messages'][] = [
                "from" => $user_lookup[$from_email],
                "to" => $user_lookup[$to_email],
                "message" => $message_content,
                "datetime" => $message_datetime,
                "sent_by_current_user" => $from_email == $_SESSION['email'],
                "index" => $index
            ];
        }
    }
}

// Lire les informations de blocage
$blocks = file($blocked_filename, FILE_IGNORE_NEW_LINES);
$blocked_users = [];
foreach ($blocks as $block) {
    list($bloqueur, $bloque) = explode(',', $block);
    if (!isset($blocked_users[$bloque])) {
        $blocked_users[$bloque] = [];
    }
    $blocked_users[$bloque][] = $bloqueur;
}

$selected_contact_email = isset($_GET['contact']) ? $_GET['contact'] : null;
$selected_contact_name = $selected_contact_email ? $user_lookup[$selected_contact_email] : null;
$selected_messages = $selected_contact_email ? $contact_messages[$selected_contact_email]['messages'] : [];
$is_blocked = $selected_contact_email && ((isset($blocked_users[$_SESSION['email']]) && in_array($selected_contact_email, $blocked_users[$_SESSION['email']])) || (isset($blocked_users[$selected_contact_email]) && in_array($_SESSION['email'], $blocked_users[$selected_contact_email])));

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="messagerie.css">
    <title>Messagerie - Cy-Sport</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url("amo.jpg");
            background-repeat: no-repeat;
            background-size: cover;
        }
    </style>
</head>
<body>
    <div class="header">
        <a href="page_profil.php" class="back-button">Retour</a>
        <h1>Messagerie</h1>
    </div>

    <div class="content">
        <div class="contacts-list">
            <ul>
                <?php
                foreach ($contact_messages as $contact_email => $contact) {
                    $contact_image = isset($user_images[$contact_email]) ? $user_images[$contact_email] : 'default.png';
                    $contact_image_path = 'images/' . $contact_image;
                    echo "<li><img src='" . htmlspecialchars($contact_image_path) . "' alt='Photo de profil'><a href='messagerie.php?contact=" . urlencode($contact_email) . "'>" . htmlspecialchars($contact['name']) . "</a></li>";
                }
                ?>
            </ul>
        </div>

        <div class="chat-container">
            <?php
            if ($selected_contact_email) {
                if (empty($selected_messages)) {
                    echo "<p>Aucun message à afficher.</p>";
                } else {
                    echo "<h2>Conversation avec " . htmlspecialchars($selected_contact_name) . "</h2>";
                    foreach ($selected_messages as $msg) {
                        $class = $msg['sent_by_current_user'] ? 'sent' : 'received';
                        $sender = $msg['sent_by_current_user'] ? 'Vous' : htmlspecialchars($msg['from']);
                        echo "<div class='chat-message $class'>";
                        echo "<div class='message-datetime'>" . htmlspecialchars($msg['datetime']) . "</div>";
                        echo "<div class='message-sender'>$sender</div>";
                        echo "<div class='message-content'>" . htmlspecialchars($msg['message']) . "</div>";
                        echo "<div class='message-actions'>";
                        if ($msg['sent_by_current_user']) {
                            echo "<form method='post' action='supprimer_message.php' style='display:inline;'>";
                            echo "<input type='hidden' name='message_index' value='" . $msg['index'] . "'>";
                            echo "<input type='hidden' name='contact_email' value='" . htmlspecialchars($selected_contact_email) . "'>";
                            echo "<button type='submit' class='delete-button'>Supprimer</button>";
                            echo "</form>";
                        } else {
                            echo "<form method='post' action='signaler_message.php' style='display:inline;'>";
                            echo "<input type='hidden' name='message_content' value='" . htmlspecialchars($msg['message']) . "'>";
                            echo "<input type='hidden' name='contact_email' value='" . htmlspecialchars($selected_contact_email) . "'>";
                            echo "<input type='hidden' name='message_author' value='" . htmlspecialchars($msg['from']) . "'>";
                            echo "<button type='submit' class='report-button'>Signaler</button>";
                            echo "</form>";
                        }
                        echo "</div>";
                        echo "</div>";
                    }
                }
            } else {
                echo "<p>Sélectionnez un contact pour voir les messages.</p>";
            }
            ?>

            <?php if ($selected_contact_email && !$is_blocked): ?>
            <form class="message-form" method="post" action="envoyer_message.php">
                <input type="hidden" name="to_email" value="<?php echo htmlspecialchars($selected_contact_email); ?>">
                <textarea name="message" rows="4" placeholder="Tapez votre message ici..." required></textarea>
                <button type="submit">Envoyer</button>
            </form>
            <?php elseif ($is_blocked): ?>
            <p>Vous ne pouvez pas envoyer de message à cette personne car elle vous a bloqué ou vous l'avez bloqué.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>

