<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];
    $filename = 'profils.php';
    $users = file($filename, FILE_IGNORE_NEW_LINES);
    $is_authenticated = false;
    foreach ($users as $user) {
        $user_data = explode(',', $user);
        if ($user_data[7] == $email && $user_data[8] == $password) {
            $_SESSION["email"] = $email;
            $is_authenticated = true;
            break;
        }
    }
    if ($is_authenticated) {
        header("Location: pageProfils.php");
        exit(); 
    } else {
        header("Location: connexion.html?error=1");
        exit();
    }
}
?>
