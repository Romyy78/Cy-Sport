<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: connexion.html");
    exit();
}

$filename = 'utilisateurs.txt';
$reports_filename = 'signalementsmessages.txt';
$users = file($filename, FILE_IGNORE_NEW_LINES);
$reports = file($reports_filename, FILE_IGNORE_NEW_LINES);

$current_user_email = $_SESSION['email'];
$is_admin = false;

foreach ($users as &$user) {
    $user_data = explode(',', $user);
    if ($user_data[8] == $current_user_email && $user_data[9] == 'admin') {
        $is_admin = true;
        break;
    }
}

if (!$is_admin) {
    header("Location: page_profil.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="messages_signales.css">
    <title>Administration - Messages signalés</title>
</head>
<body>
    <div class="container">
        <h2>Messages signalés</h2>
        <?php
        if (isset($error_message) && !empty($error_message)) {
            echo "<p class='error-message'>" . htmlspecialchars($error_message) . "</p>";
        }

        if (!empty($banned_message)) {
            echo "<p class='success-message'>" . htmlspecialchars($banned_message) . "</p>";
        }

        if (empty($reports)) {
            echo "<p>Aucun message signalé.</p>";
        } else {
            foreach ($reports as $report) {
                echo "<div class='report'>";
                echo "<p><strong>Message :</strong> " . htmlspecialchars($report) . "</p>";
                echo "</div>";
            }
        }
        ?>
        <button class="back-button" onclick="window.location.href='page_profil.php';">Retour</button>
    </div>
</body>
</html>

