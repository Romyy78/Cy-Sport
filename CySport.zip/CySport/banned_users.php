<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: connexion.html");
    exit();
}

$filename = 'utilisateurs.txt';
$users = file($filename, FILE_IGNORE_NEW_LINES);

$current_user_email = $_SESSION['email'];
$is_admin = false;

foreach ($users as $user) {
    $user_data = explode(',', $user);
    if ($user_data[8] == $current_user_email && $user_data[9] == 'admin') {
        $is_admin = true;
        break;
    }
}

if (!$is_admin) {
    header("Location: page_profil.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['unban_email'])) {
    $unban_email = filter_var($_POST['unban_email'], FILTER_VALIDATE_EMAIL);
    if ($unban_email) {
        foreach ($users as &$user) {
            $user_data = explode(',', $user);
            if ($user_data[8] == $unban_email && isset($user_data[13]) && trim($user_data[13]) === 'ban') {
                $user_data[13] = 'unb';
                $user = implode(',', $user_data);
                break;
            }
        }
        file_put_contents($filename, implode("\n", $users) . "\n");
        header("Location: banned_users.php?status=success");
        exit();
    } else {
        header("Location: banned_users.php?status=error&message=Email invalide");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="banned_users.css">
    <title>Utilisateurs bannis - Cy-Sport</title>
</head>
<body>
    <div class="container">
        <a href="page_profil.php" class="back-button">Retour</a>
        <h2>Utilisateurs bannis</h2>
        <?php
        if (isset($_GET['status'])) {
            $status = $_GET['status'];
            $message = isset($_GET['message']) ? urldecode($_GET['message']) : '';
            if ($status == 'success') {
                echo "<p class='success-message'>Utilisateur débanni avec succès.</p>";
            } elseif ($status == 'error') {
                echo "<p class='error-message'>Erreur : $message</p>";
            }
        }

        foreach ($users as $user) {
            $user_data = explode(',', $user);
            if (isset($user_data[13]) && trim($user_data[13]) === 'ban') {
                echo "<div class='user'>";
                echo "<p><strong>Email :</strong> " . htmlspecialchars($user_data[8]) . "</p>";
                echo "<p><strong>Nom :</strong> " . htmlspecialchars($user_data[1]) . " " . htmlspecialchars($user_data[2]) . "</p>";
                echo "<form method='post' style='display:inline;'>";
                echo "<input type='hidden' name='unban_email' value='" . htmlspecialchars($user_data[8]) . "'>";
                echo "<button type='submit' class='unban-button'>Débannir l'utilisateur</button>";
                echo "</form>";
                echo "</div>";
            }
        }
        ?>
    </div>
</body>
</html>

