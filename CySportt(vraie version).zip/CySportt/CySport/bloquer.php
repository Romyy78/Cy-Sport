<?php
session_start();
if (!isset($_SESSION['email']) || !isset($_GET['email'])) {
    header("Location: connexion.html");
    exit();
}

// Chemins relatifs vers les fichiers dans le dossier parent
$blocked_filename = '../data/blocked_users.txt';
$users_filename = '../data/utilisateurs.txt'; 
$current_user_email = $_SESSION['email'];
$blocked_user_email = $_GET['email'];

// Vérifiez que les fichiers existent avant de les lire
if (!file_exists($users_filename)) {
    die('Le fichier de données utilisateurs est introuvable : ' . $users_filename);
}

if (!file_exists($blocked_filename)) {
    file_put_contents($blocked_filename, "");
}

$users = file($users_filename, FILE_IGNORE_NEW_LINES);
$blocked_users = file($blocked_filename, FILE_IGNORE_NEW_LINES);

foreach ($users as $user) {
    $user_data = explode(',', $user);
    if ($user_data[8] == $blocked_user_email && $user_data[9] == 'admin') {
        header("Location: page_profil.php?status=error&message=" . urlencode("Impossible de bloquer un admin."));
        exit();
    }
}

$entry = $current_user_email . ',' . $blocked_user_email;

if (!in_array($entry, $blocked_users)) {
    $blocked_users[] = $entry;
    file_put_contents($blocked_filename, implode("\n", $blocked_users) . "\n");
}

header("Location: page_profil.php?status=success&message=" . urlencode("Utilisateur bloqué avec succès."));
exit();
?>

