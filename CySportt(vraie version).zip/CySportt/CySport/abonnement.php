<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: connexion.html");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['offre'])) {
    $offre = $_POST['offre'];
    $_SESSION['offre'] = $offre; // Stocker l'offre dans la session
    header("Location: paiement.php"); // Rediriger vers la page de paiement
    exit();
} else {
    header("Location: choisir_offre.php");
    exit();
}
?>

