<!DOCTYPE html>
<html>
<head>
  <title>Inscription</title>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="white-block">
    <li class="btn1"><a href="accueil.html">Accueil</a></li>
    <li class="btn1"><a href="connexion.html">Se connecter</a></li>
    <ul class="submenu">
        <!-- Additional submenu items can go here -->
    </ul>

    <h1>Veuillez vous inscrire</h1>

    <form method="POST" action="VerifInscrip2.php">
        <fieldset>
            <legend>Informations personnelles</legend>
            <?php $sexeOption = ['Monsieur', 'Madame']; ?>
            <?php foreach($sexeOption as $sexeOption): ?>
                <label for="sexe_<?php echo $sexeOption; ?>"><?php echo $sexeOption; ?></label>
                <input type="radio" name="Sexe" id="sexe_<?php echo $sexeOption; ?>" value="<?php echo $sexeOption; ?>">
            <?php endforeach; ?>
            <br>
            <label for="nom">Votre Nom:</label>
            <input type="text" id="nom" name="nom" placeholder="Entrer votre nom..." required>
            <br>
            <label for="prenom">Votre Prénom:</label>
            <input type="text" id="prenom" name="prenom" placeholder="Entrer votre prénom..." required>
            <br>
            <label for="pseudo">Votre Pseudo:</label>
            <input type="text" id="pseudo" name="pseudo" placeholder="Entrer votre pseudo..." required>
            <br>
            <label for="date_naissance">Date de naissance:</label>
            <input type="date" id="date_naissance" name="date_naissance" max="2006-04" value="2006-04" required>
            <br>
            <label for="codepostal">Code Postal:</label>
            <input type="text" id="codepostal" name="codepostal" placeholder="Entrer votre code postal..." required>
            <br>
            <label for="ville">Ville:</label>
            <input type="text" id="ville" name="ville" placeholder="Entrer votre Ville..." required>
            <br>
            <label for="pays">Pays:</label>
            <select id="pays" name="pays">
                <option value="France">France</option>
                <!-- Autres options -->
            </select>
        </fieldset>
        <fieldset>
            <legend>Informations de contact</legend>
            <label for="email">Votre E-mail:</label>
            <input type="email" id="email" name="email" placeholder="Entrer votre E-mail..." required>
            <br>
            <label for="pass">Votre Mot de passe:</label>
            <input type="text" id="pass" name="pass" placeholder="Entrer votre Mot de passe..." required>
            <br>
            <input type="submit" value="S'inscrire !!">
        </fieldset>
    </form>
    </div>
    <div class="logo-container">
        <?php $logoSrc = "logo.png"; ?>
        <img src="<?php echo $logoSrc; ?>" alt="Logo" class="logo">
    </div>
</body>
</html>
