<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: connexion.html");
    exit();
}

$blocked_filename = 'blocked_users.txt';
$users_filename = 'utilisateurs.txt';
if (!file_exists($blocked_filename)) {
    file_put_contents($blocked_filename, "");
}
$blocked_users = file($blocked_filename, FILE_IGNORE_NEW_LINES);
$users = file($users_filename, FILE_IGNORE_NEW_LINES);

$current_user_email = $_SESSION['email'];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['unblock_email'])) {
    $unblock_email = $_POST['unblock_email'];
    $blocked_users = array_filter($blocked_users, function($entry) use ($current_user_email, $unblock_email) {
        return $entry !== $current_user_email . ',' . $unblock_email;
    });
    file_put_contents($blocked_filename, implode("\n", $blocked_users) . "\n");
    header("Location: bloques.php");
    exit();
}

function getUserDataByEmail($email) {
    global $users;
    foreach ($users as $user) {
        $user_data = explode(',', $user);
        if ($user_data[8] == $email) {
            return $user_data;
        }
    }
    return null;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bloques.css">
    <title>Utilisateurs bloqués - Cy-Sport</title>
</head>
<body>
    <div class="header">
        <a href="page_profil.php" class="back-button">Retour</a>
        <h1>Utilisateurs bloqués</h1>
    </div>

    <div class="content">
        <div class="blocked-users-container">
            <h2>Liste des utilisateurs bloqués</h2>
            <?php
            $blocked_count = 0;
            foreach ($blocked_users as $entry) {
                list($blocker, $blocked) = explode(',', $entry);
                if ($blocker == $current_user_email) {
                    $blocked_user_data = getUserDataByEmail($blocked);
                    if ($blocked_user_data) {
                        $blocked_count++;
                        echo "<div class='blocked-user'>";
                        echo "<p>" . htmlspecialchars($blocked_user_data[1]) . " " . htmlspecialchars($blocked_user_data[2]) . "</p>";
                        echo "<form method='post' style='display:inline;'>";
                        echo "<input type='hidden' name='unblock_email' value='" . htmlspecialchars($blocked) . "'>";
                        echo "<button type='submit' class='unblock-button'>Débloquer</button>";
                        echo "</form>";
                        echo "</div>";
                    }
                }
            }
            if ($blocked_count == 0) {
                echo "<p>Aucun utilisateur bloqué.</p>";
            }
            ?>
        </div>
    </div>
</body>
</html>

