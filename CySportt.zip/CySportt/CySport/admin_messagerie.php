<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: connexion.html");
    exit();
}

// Chemins relatifs vers les fichiers dans le dossier parent
$users_filename = '../data/utilisateurs.txt';
$messages_filename = '../data/messages.txt';

// Vérifiez que les fichiers existent avant de les lire
if (!file_exists($users_filename) || !file_exists($messages_filename)) {
    die('Un ou plusieurs fichiers de données sont introuvables.');
}

// Lire les utilisateurs
$users = file($users_filename, FILE_IGNORE_NEW_LINES);
$user_lookup = [];
$user_images = [];
foreach ($users as $user) {
    list($sexe, $prenom, $nom, $pseudo, $naissance, $ville, $code_postal, $pays, $email, $mot_de_passe, $role, $couleur_preferee, $date_expiration, $status, $image_profil) = explode(',', $user);
    $user_lookup[$email] = $prenom . ' ' . $nom;
    $user_images[$email] = $image_profil ?: 'default.png'; // Fallback to default image
}

$messages = file($messages_filename, FILE_IGNORE_NEW_LINES);
$contact_messages = [];

foreach ($messages as $message) {
    if (preg_match('/From: ([^,]+), To: ([^,]+), Message: (.+), Datetime: (.+)/', $message, $matches)) {
        $from_email = trim($matches[1]);
        $to_email = trim($matches[2]);
        $message_content = trim($matches[3]);
        $message_datetime = trim($matches[4]);

        if (!isset($contact_messages[$from_email])) {
            $contact_messages[$from_email] = [];
        }
        if (!isset($contact_messages[$to_email])) {
            $contact_messages[$to_email] = [];
        }
        
        $contact_messages[$from_email][$to_email][] = [
            "from" => $user_lookup[$from_email],
            "to" => $user_lookup[$to_email],
            "message" => $message_content,
            "datetime" => $message_datetime,
            "sent_by_current_user" => false
        ];
        $contact_messages[$to_email][$from_email][] = [
            "from" => $user_lookup[$from_email],
            "to" => $user_lookup[$to_email],
            "message" => $message_content,
            "datetime" => $message_datetime,
            "sent_by_current_user" => true
        ];
    }
}

$selected_user_email = isset($_GET['user']) ? $_GET['user'] : null;
$selected_user_name = $selected_user_email ? $user_lookup[$selected_user_email] : null;

$selected_contact_email = isset($_GET['contact']) ? $_GET['contact'] : null;
$selected_contact_name = $selected_contact_email ? $user_lookup[$selected_contact_email] : null;

$selected_messages = ($selected_user_email && $selected_contact_email) ? $contact_messages[$selected_user_email][$selected_contact_email] : [];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="admin_messagerie.css">
    <title>Messagerie Admin - Cy-Sport</title>
</head>
<body>
    <div class="header">
        <a href="javascript:void(0);" id="backButton" class="back-button">Retour</a>
        <h1>Messagerie Admin</h1>
    </div>

    <div class="content">
        <div class="contacts-list">
            <ul>
                <?php
                if (!$selected_user_email) {
                    foreach ($user_lookup as $email => $name) {
                        $contact_image = isset($user_images[$email]) ? $user_images[$email] : 'default.png';
                        $contact_image_path = 'images/' . $contact_image;
                        echo "<li><img src='" . htmlspecialchars($contact_image_path) . "' alt='Photo de profil'><a href='admin_messagerie.php?user=" . urlencode($email) . "'>" . htmlspecialchars($name) . "</a></li>";
                    }
                } elseif (!$selected_contact_email) {
                    foreach ($contact_messages[$selected_user_email] as $contact_email => $messages) {
                        $contact_image = isset($user_images[$contact_email]) ? $user_images[$contact_email] : 'default.png';
                        $contact_image_path = 'images/' . $contact_image;
                        echo "<li><img src='" . htmlspecialchars($contact_image_path) . "' alt='Photo de profil'><a href='admin_messagerie.php?user=" . urlencode($selected_user_email) . "&contact=" . urlencode($contact_email) . "'>" . htmlspecialchars($user_lookup[$contact_email]) . "</a></li>";
                    }
                }
                ?>
            </ul>
        </div>

        <div class="chat-container">
            <?php
            if ($selected_user_email && $selected_contact_email) {
                if (empty($selected_messages)) {
                    echo "<p>Aucun message à afficher.</p>";
                } else {
                    echo "<h2>Conversation entre " . htmlspecialchars($user_lookup[$selected_user_email]) . " et " . htmlspecialchars($selected_contact_name) . "</h2>";
                    foreach ($selected_messages as $msg) {
                        $class = $msg['sent_by_current_user'] ? 'sent' : 'received';
                        $sender = htmlspecialchars($msg['from']);
                        echo "<div class='chat-message $class'>";
                        echo "<div class='message-datetime'>" . htmlspecialchars($msg['datetime']) . "</div>";
                        echo "<div class='message-sender'>$sender</div>";
                        echo "<div class='message-content'>" . htmlspecialchars($msg['message']) . "</div>";
                        echo "</div>";
                    }
                }
            } else {
                echo "<p>Sélectionnez un utilisateur puis un destinataire pour voir les messages.</p>";
            }
            ?>
        </div>
    </div>
    <script>
        document.getElementById('backButton').addEventListener('click', function() {
            history.back();
        });
    </script>
</body>
</html>

