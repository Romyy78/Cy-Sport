<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: connexion.html");
    exit();
}

$filename = 'utilisateurs.txt';
$signalements_filename = 'signalements.txt';
$users = file($filename, FILE_IGNORE_NEW_LINES);
$signalements = file($signalements_filename, FILE_IGNORE_NEW_LINES);

$current_user_email = $_SESSION['email'];
$is_admin = false;

foreach ($users as &$user) {
    $user_data = explode(',', $user);
    if ($user_data[8] == $current_user_email && $user_data[9] == 'admin') {
        $is_admin = true;
        break;
    }
}

if (!$is_admin) {
    header("Location: page_profil.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="admin_signalements.css">
    <title>Administration - Signalements</title>
    </head>
<body>
    <div class="container">
        <h2>Signalements des utilisateurs</h2>
        <?php
        if (isset($error_message) && !empty($error_message)) {
            echo "<p class='error-message'>" . htmlspecialchars($error_message) . "</p>";
        }

        if (!empty($banned_message)) {
            echo "<p class='success-message'>" . htmlspecialchars($banned_message) . "</p>";
        }

        if (empty($signalements)) {
            echo "<p>Aucun signalement.</p>";
        } else {
            foreach ($signalements as $signalement) {
                list($reporter, $reported, $message) = explode(',', $signalement);
                echo "<div class='signalement'>";
                echo "<p><strong>Signalé par :</strong> " . htmlspecialchars($reporter) . "</p>";
                echo "<p><strong>Utilisateur signalé :</strong> " . htmlspecialchars($reported) . "</p>";
                echo "<p><strong>Message :</strong> " . htmlspecialchars($message) . "</p>";
                echo "</div>";
            }
        }
        ?>
        <button class="back-button" onclick="window.location.href='page_profil.php';">Retour</button>
    </div>
</body>
</html>

