<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: connexion.html");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['logout'])) {
    session_destroy();
    header("Location: connexion.html");
    exit();
}

$filename = 'utilisateurs.txt';
$users = file($filename, FILE_IGNORE_NEW_LINES);
$blocked_filename = 'blocked_users.txt';
if (!file_exists($blocked_filename)) {
    file_put_contents($blocked_filename, "");
}
$blocked_users = file($blocked_filename, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
$blocked_users_map = [];

foreach ($blocked_users as $blocked_entry) {
    list($blocker, $blocked) = explode(',', $blocked_entry);
    $blocked_users_map[$blocker][] = $blocked;
}

$found_user_key = null;
$current_user_offer = null;
$current_user_email = $_SESSION['email'];
$is_admin = false;

foreach ($users as $key => $user) {
    $user_data = explode(',', $user);
    if ($user_data[8] == $current_user_email) {
        $found_user_key = $key;
        $current_user_offer = strtolower($user_data[11]);
        $expiration_date = DateTime::createFromFormat('d-m-Y', $user_data[12]);
        $current_date = new DateTime();
        
        if ($expiration_date) {
            if ($current_user_offer == 'black') {
                $expiration_date->modify('+1 year');
            } elseif ($current_user_offer == 'premium') {
                $expiration_date->modify('+3 months');
            } elseif ($current_user_offer == 'basique') {
                $expiration_date->modify('+1 month');
            }
            
            if ($expiration_date < $current_date) {
                // Mettre à jour l'abonnement de l'utilisateur
                $user_data[11] = 'a';
                $users[$key] = implode(',', $user_data);
                file_put_contents($filename, implode("\n", $users) . "\n");
                $current_user_offer = 'a';
            }
        }

        if ($user_data[9] == 'admin') {
            $is_admin = true;
        }
        break;
    }
}

function handleVotes($current_user_email) {
    $votesFile = 'votes.txt';
    if (!file_exists($votesFile)) {
        file_put_contents($votesFile, "");
    }
    $votes = file($votesFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $votesMap = [];
    $userVotes = [];

    foreach ($votes as $vote) {
        list($voter, $email, $type) = explode(',', $vote);
        if (!isset($votesMap[$email])) {
            $votesMap[$email] = ['up' => 0, 'down' => 0];
        }
        if ($type == 'up') {
            $votesMap[$email]['up']++;
        } elseif ($type == 'down') {
            $votesMap[$email]['down']++;
        }

        if ($voter == $current_user_email) {
            $userVotes[$email] = $type;
        }
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['vote'])) {
        $voteType = $_POST['vote'];
        $voteEmail = $_POST['email'];

        if ($voteEmail != $current_user_email && !isset($userVotes[$voteEmail]) && ($voteType == 'up' || $voteType == 'down')) {
            $votes[] = $current_user_email . ',' . $voteEmail . ',' . $voteType;
            file_put_contents($votesFile, implode("\n", $votes) . "\n");
        }

        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }

    return $votesMap;
}

$votesMap = handleVotes($current_user_email);

function displayProfile($user, $isCurrentUser, $current_user_offer, $votesMap, $current_user_email) {
    global $blocked_users_map, $is_admin;
    $user_data = explode(',', $user);
    $isAdmin = ($user_data[9] == 'admin');
    $user_email = $user_data[8];

    // Ne pas afficher les utilisateurs bannis
    if (isset($user_data[13]) && trim($user_data[13]) === 'ban') {
        return;
    }

    // Ne pas afficher les utilisateurs bloqués par l'utilisateur courant
    if (isset($blocked_users_map[$current_user_email]) && in_array($user_email, $blocked_users_map[$current_user_email])) {
        return;
    }

    $totalVotes = isset($votesMap[$user_email]) ? $votesMap[$user_email]['up'] + $votesMap[$user_email]['down'] : 0;
    $upVotes = isset($votesMap[$user_email]) ? $votesMap[$user_email]['up'] : 0;
    $downVotes = isset($votesMap[$user_email]) ? $votesMap[$user_email]['down'] : 0;
    $upPercentage = ($totalVotes > 0) ? ($upVotes / $totalVotes) * 100 : 0;
    $downPercentage = ($totalVotes > 0) ? ($downVotes / $totalVotes) * 100 : 0;

    echo "<div class='profile-container'>";
    echo "<div class='profile'>";
    if ($isCurrentUser) {
        echo "<div class='profile-heading'>Votre Profil</div>";
    }
    echo "<img src='images/" . htmlspecialchars($user_data[14]) . "' alt='Photo de profil'>";
    echo "<h2>";
    if ($isAdmin) {
        echo "<span class='admin-indicator'>✔️</span> ";
    }
    echo htmlspecialchars($user_data[1]) . " " . htmlspecialchars($user_data[2]) . "</h2>";

    if (!$isCurrentUser && $current_user_offer !== 'a' && !$isAdmin) {
        echo "<a href='bloquer.php?email=" . urlencode($user_email) . "' class='action-button block-button'>Bloquer</a> ";
        if ($is_admin) {
            echo "<form method='post' action='bannir_utilisateur.php' style='display:inline;'>";
            echo "<input type='hidden' name='ban_email' value='" . htmlspecialchars($user_email) . "'>";
            echo "<button type='submit' class='action-button report-button'>Bannir l'utilisateur</button>";
            echo "</form>";
        } else {
            echo "<a href='signaler.php?email=" . urlencode($user_email) . "' class='action-button report-button'>Signaler</a> ";
        }
    }

    // Ne pas afficher le bouton "Envoyer un message" si l'utilisateur actuel est bloqué par ce profil
    if (!$isCurrentUser && $current_user_offer !== 'a' && 
        !(isset($blocked_users_map[$user_email]) && in_array($current_user_email, $blocked_users_map[$user_email]))) {
        echo "<a href='envoyer_message.php?email=" . urlencode($user_email) . "&name=" . urlencode($user_data[1] . ' ' . $user_data[2]) . "' class='action-button'>Envoyer un message</a>";
    }

    if ($is_admin && !$isCurrentUser && !$isAdmin) {
        echo "<a href='modifier_informations_profil.php?email=" . urlencode($user_email) . "' class='action-button edit-profile-button'>Modifier les informations du profil</a>";
        echo "<form method='post' action='' style='display:inline;'>";
        echo "<input type='hidden' name='delete_email' value='" . htmlspecialchars($user_email) . "'>";
        echo "<button type='submit' name='delete_profile' class='action-button delete-profile-button'>Supprimer le profil</button>";
        echo "</form>";
    }

    // Ajouter le bouton "Consulter le profil"
    echo "<a href='consulterprof.php?email=" . urlencode($user_email) . "' class='action-button view-profile-button'>Consulter le profil</a>";

    if (!$isAdmin) {
        echo "<div class='vote-buttons'>";
        if (!isset($votesMap[$current_user_email . ',' . $user_email])) {
            echo "<form method='post'>";
            echo "<input type='hidden' name='email' value='" . htmlspecialchars($user_email) . "'>";
            echo "<button type='submit' name='vote' value='up' class='vote-button'>👍</button>";
            echo "<button type='submit' name='vote' value='down' class='vote-button'>👎</button>";
            echo "</form>";
        } else {
            echo "<div class='vote-message'>Vous avez déjà voté.</div>";
        }
        echo "<div class='vote-percentage'>👍 ". round($upPercentage) ."%</div>";
        echo "<div class='vote-percentage'>👎 ". round($downPercentage) ."%</div>";
        echo "</div>";
    }

    echo "</div>";
    echo "</div>";
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_profile'])) {
    $delete_email = $_POST['delete_email'];
    
    $users = file($filename, FILE_IGNORE_NEW_LINES);
    $deleted_user = null;
    
    foreach ($users as $key => $user) {
        $user_data = explode(',', $user);
        if ($user_data[8] == $delete_email) {
            $deleted_user = $user;
            unset($users[$key]);
            break;
        }
    }
    
    if ($deleted_user) {
        file_put_contents($filename, implode("\n", $users) . "\n");
        file_put_contents('utilisateursSupprimes.txt', $deleted_user . "\n", FILE_APPEND);
        header("Location: page_profil.php?status=success&message=" . urlencode("Le profil a été supprimé avec succès."));
        exit();
    } else {
        header("Location: page_profil.php?status=error&message=" . urlencode("Erreur lors de la suppression du profil."));
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil - Cy-Sport</title>
    <link rel="stylesheet" href="page_profil.css">
</head>
<body>
    <div class="header">
        <h1>Cy-sport</h1>
        <div style="color: white; margin-top: 10px;">
            <?php echo "Date et heure actuelle : " . date("d-m-Y H:i:s"); ?>
        </div>
        <form method="post" style="display: inline;">
            <button type="submit" name="logout" class="button logout-button">Se déconnecter</button>
        </form>
    </div>

    <div class="buttons-container">
        <a href="modifier_profil.php" class="button edit-profile-button">Modifier votre profil</a>
        <a href="choisir_offre.php" class="button change-subscription-button">Modifier son offre d'abonnement</a>
        <?php
        if (!empty($current_user_offer) && in_array($current_user_offer, ['basique', 'premium', 'black'])) {
            echo '<a href="visites_profil.php" class="button">Visites du profil</a>';
        }
        if (!empty($current_user_offer)) {
            echo '<a href="messagerie.php" class="button messaging-button">Messagerie</a>';
        }
        if ($is_admin) {
            echo '<a href="admin_signalements.php" class="button admin-button">Administration</a>';
            echo '<a href="banned_users.php" class="button banned-users-button">Utilisateurs bannis</a>';
            echo '<a href="admin_messagerie.php" class="button user-messages-button">Messages des utilisateurs</a>';
            echo '<a href="messages_signales.php" class="button admin-button">Messages signalés</a>';
        }
        ?>
        <a href="bloques.php" class="button blocked-users-button">Utilisateurs bloqués</a>
    </div>

    <form method="get" action="page_profil.php" style="text-align: center; margin: 20px 0;">
        <input type="text" name="search" placeholder="Rechercher par nom ou prénom" style="padding: 10px; width: 300px; border-radius: 5px; border: 1px solid #ccc;">
        <button type="submit" class="button" style="background-color: green; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer;">Rechercher</button>
    </form>

    <div class="content">
        <?php
        if (isset($_GET['status'])) {
            $status = $_GET['status'];
            $message = isset($_GET['message']) ? urldecode($_GET['message']) : '';
            if ($status == 'success') {
                echo "<div class='message success'>Action effectuée avec succès.</div>";
            } elseif ($status == 'error') {
                echo "<div class='message error'>Erreur : $message</div>";
            }
        }

        if ($found_user_key !== null) {
            displayProfile($users[$found_user_key], true, $current_user_offer, $votesMap, $current_user_email);

            $profile_count = 0;
            $max_profiles = ($current_user_offer == 'basique') ? PHP_INT_MAX : PHP_INT_MAX; // No limit for 'basique'

            // Gestion de la recherche
            $search = isset($_GET['search']) ? strtolower(trim($_GET['search'])) : '';

            foreach ($users as $key => $user) {
                if ($key === $found_user_key) {
                    continue;
                }

                $user_data = explode(',', $user);
                $full_name = strtolower($user_data[1] . ' ' . $user_data[2]);

                if ($search && strpos($full_name, $search) === false) {
                    continue;
                }

                if ($profile_count >= $max_profiles) {
                    break;
                }

                displayProfile($user, false, $current_user_offer, $votesMap, $current_user_email);
                $profile_count++;
            }
        } else {
            echo "<p>Aucun profil trouvé pour l'utilisateur connecté.</p>";
        }
        ?>
    </div>
</body>
</html>

