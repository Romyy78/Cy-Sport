<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: connexion.html");
    exit();
}

$current_user_email = $_SESSION['email'];

$filename = '../data/utilisateurs.txt';
$users = file($filename, FILE_IGNORE_NEW_LINES);

$visits_filename = '../data/visites.txt';
$visits = file($visits_filename, FILE_IGNORE_NEW_LINES);
$visitors = [];

foreach ($visits as $visit) {
    list($visited_email, $visitor_email, $visit_date) = explode(',', $visit);
    if ($visited_email == $current_user_email) {
        $visitors[] = ['email' => $visitor_email, 'date' => $visit_date];
    }
}

function getUserByEmail($email, $users) {
    foreach ($users as $user) {
        $user_data = explode(',', $user);
        if ($user_data[8] == $email) {
            return $user_data;
        }
    }
    return null;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style2.css">
    <title>Visites de profil - Cy-Sport</title>
   
</head>
<body>
    <div class="header" >
        <h1>Cy-Sport</h1>
        <form method="post" action="logout.php" style="display: inline;">
            <button type="submit" class="logout-button">Se déconnecter</button>
        </form>
        <a href="page_profil.php" class="back-button">Retour</a>
    </div>
    <div class="content" style="text-align: center;">
        <h2>Personnes ayant visité votre profil</h2>
        <?php
        if (empty($visitors)) {
            echo "<p>Aucune visite pour le moment.</p>";
        } else {
            foreach ($visitors as $visitor) {
                $visitor_data = getUserByEmail($visitor['email'], $users);
                if ($visitor_data) {
                    $visitor_name = htmlspecialchars($visitor_data[1]) . ' ' . htmlspecialchars($visitor_data[2]);
                    $visitor_image = htmlspecialchars($visitor_data[14]);
                    $visitor_image_path = 'images/' . $visitor_image;
                    if (!file_exists($visitor_image_path) || empty($visitor_image)) {
                        $visitor_image_path = 'images/default.png';
                    }
                    echo "<div class='visit'>";
                    echo "<img src='" . $visitor_image_path . "' alt='Photo de profil'>";
                    echo "<div>";
                    echo "<h2>" . $visitor_name . "</h2>";
                    echo "<p>Date de visite: " . htmlspecialchars($visitor['date']) . "</p>";
                    echo "</div>";
                    echo "<a href='consulterprof.php?email=" . urlencode($visitor['email']) . "' class='profile-button'>Consulter le profil</a>";
                    echo "</div>";
                }
            }
        }
        ?>
    </div>
</body>
</html>

