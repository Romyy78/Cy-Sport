<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $pass = $_POST["pass"];
    $filename = '../data/utilisateurs.txt'; 
    $users = file($filename, FILE_IGNORE_NEW_LINES);
    $is_authenticated = false;
    $is_banned = false;

    foreach ($users as $user) {
        $user_data = explode(',', $user);
        if ($user_data[8] == $email) {
            if (isset($user_data[13]) && trim($user_data[13]) === 'ban') {
                $is_banned = true;
                break;
            }
            if ($user_data[10] == $pass) {
                $_SESSION["email"] = $email;
                $is_authenticated = true;
                break;
            }
        }
    }

    if ($is_banned) {
        $_SESSION['error_message'] = "Vous avez été banni.";
        header("Location: connexion.html");
        exit();
    } elseif ($is_authenticated) {
        header("Location: page_profil.php");
        exit(); 
    } else {
        $_SESSION['error_message'] = "Email ou mot de passe incorrect.";
        header("Location: connexion.html");
        exit();
    }
}
?>

