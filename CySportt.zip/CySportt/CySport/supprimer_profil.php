<?php
function supprimerProfil($email) {
    $filename = '../data/utilisateurs.txt';
    $deleted_filename = '../data/utilisateursSupprimes.txt';

    if (!file_exists($filename)) {
        die('Le fichier de données utilisateurs est introuvable.');
    }

    $users = file($filename, FILE_IGNORE_NEW_LINES);
    $deleted_user = null;

    foreach ($users as $key => $user) {
        $user_data = explode(',', $user);
        if ($user_data[8] == $email) {
            $deleted_user = $user;
            unset($users[$key]);
            break;
        }
    }

    if ($deleted_user) {
        // Sauvegarde des utilisateurs restants
        file_put_contents($filename, implode("\n", $users) . "\n");

        // Ajout de l'utilisateur supprimé dans le fichier utilisateursSupprimes.txt
        file_put_contents($deleted_filename, $deleted_user . "\n", FILE_APPEND);

        return true;
    } else {
        return false;
    }
}
?>

